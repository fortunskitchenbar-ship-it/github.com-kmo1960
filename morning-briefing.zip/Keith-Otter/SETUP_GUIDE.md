# Morning Briefing — Setup Guide
**Keith Otter | La Quinta, CA**
Sends daily at 9:00 AM PDT to kmo1960@me.com

---

## What This Does

Every morning at 9 AM, GitHub Actions automatically:
1. Fetches La Quinta weather (Open-Meteo, no key needed)
2. Pulls your Google Calendar events for today
3. Grabs top Fox News headlines
4. Sends everything to Claude, which writes a motivational spoken briefing
5. Converts the briefing to an MP3 (natural female voice)
6. Emails you the full text + MP3 attachment at kmo1960@me.com

---

## One-Time Setup (30 minutes total)

### Step 1 — Create the GitHub Repository

1. Go to [github.com](https://github.com) and sign in (create account if needed)
2. Click **New repository**
3. Name it: `morning-briefing`
4. Set to **Private**
5. Click **Create repository**
6. Upload all these files into the repo (drag and drop or use GitHub Desktop)

---

### Step 2 — Gmail App Password

You need an "App Password" — not your regular Gmail password.

1. Go to [myaccount.google.com](https://myaccount.google.com)
2. Click **Security** → **2-Step Verification** (enable it if not already on)
3. Scroll down to **App passwords**
4. Click **Create app password**
5. Name it: `Morning Briefing`
6. Copy the 16-character password it gives you — save it somewhere safe

---

### Step 3 — Google Calendar Service Account

This lets GitHub read your calendar without you logging in each time.

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project (name it anything, e.g. "Morning Briefing")
3. Go to **APIs & Services** → **Enable APIs**
4. Search for and enable: **Google Calendar API**
5. Go to **APIs & Services** → **Credentials**
6. Click **Create Credentials** → **Service Account**
7. Name it: `morning-briefing-bot` → click through to finish
8. Click on the service account you just created
9. Go to **Keys** tab → **Add Key** → **Create new key** → **JSON**
10. It downloads a `.json` file — keep this safe
11. Open your Google Calendar → Settings for your calendar → **Share with specific people**
12. Add the service account email (looks like `morning-briefing-bot@your-project.iam.gserviceaccount.com`)
13. Give it **See all event details** permission

---

### Step 4 — Add GitHub Secrets

In your GitHub repo:
1. Go to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret** for each of these:

| Secret Name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your Anthropic API key (from the screenshot) |
| `GMAIL_USER` | `fortunskitchenbar@gmail.com` |
| `GMAIL_APP_PASSWORD` | The 16-character app password from Step 2 |
| `EMAIL_TO` | `kmo1960@me.com` |
| `GOOGLE_CREDENTIALS` | Paste the entire contents of the JSON file from Step 3 |

---

### Step 5 — Test It

1. In your GitHub repo, go to **Actions** tab
2. Click **Daily Morning Briefing**
3. Click **Run workflow** → **Run workflow**
4. Watch it run — should take about 30-60 seconds
5. Check kmo1960@me.com for the email

---

## How to Play the Audio on iPhone

When the email arrives in Mail on your iPhone:
- The MP3 will appear as an attachment at the bottom
- Tap it to play inline
- Or tap and hold → **Open in Voice Memos** to save it

---

## Troubleshooting

**Email not arriving?**
- Check Gmail spam/junk folder
- Verify `GMAIL_APP_PASSWORD` secret is correct (no spaces)
- Make sure 2-Step Verification is on for fortunskitchenbar@gmail.com

**Calendar not showing?**
- Double-check the service account was shared on your calendar
- Make sure `GOOGLE_CREDENTIALS` secret contains the full JSON (including curly braces)

**Workflow not running at 9 AM?**
- GitHub Actions cron can be up to 15-20 minutes late — this is normal
- If it never runs, check the Actions tab for error messages

**Want to change the time?**
- Edit `.github/workflows/daily_agenda.yml`
- Change `cron: '0 16 * * *'`
- 9 AM PDT = 16:00 UTC | 9 AM PST (winter) = 17:00 UTC

---

## Files Reference

```
Keith-Otter/
├── .github/workflows/daily_agenda.yml   ← schedule + steps
├── scripts/
│   ├── fetch_weather.py                 ← Open-Meteo, La Quinta
│   ├── fetch_calendar.py                ← Google Calendar API
│   ├── fetch_rss.py                     ← Fox News RSS
│   ├── fetch_ai_briefing.py             ← Claude motivational briefing
│   ├── build_agenda.py                  ← combines everything
│   ├── text_to_speech.py                ← MP3 via edge-tts (Aria voice)
│   └── send_email.py                    ← Gmail SMTP
├── agenda/.gitkeep                      ← output folder
├── requirements.txt                     ← Python packages
└── SETUP_GUIDE.md                       ← this file
```
