"""
fetch_calendar.py
Pulls today's events from Google Calendar using a service account.
Requires GOOGLE_CREDENTIALS env var containing the service account JSON.
"""

import os
import json
from datetime import datetime, timezone, timedelta
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]
CALENDAR_ID = "primary"  # or your specific calendar ID
TIMEZONE = "America/Los_Angeles"


def main():
    creds_json = os.environ.get("GOOGLE_CREDENTIALS")
    if not creds_json:
        print("No GOOGLE_CREDENTIALS found — skipping calendar.")
        with open("agenda/calendar.json", "w") as f:
            json.dump([], f)
        return

    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(
        creds_info, scopes=SCOPES
    )

    service = build("calendar", "v3", credentials=creds)

    # Today's window in Pacific time
    now = datetime.now(timezone.utc)
    pst_offset = timedelta(hours=-7)  # PDT
    today_start = (now + pst_offset).replace(hour=0, minute=0, second=0, microsecond=0) - pst_offset
    today_end = today_start + timedelta(days=1)

    events_result = service.events().list(
        calendarId=CALENDAR_ID,
        timeMin=today_start.isoformat(),
        timeMax=today_end.isoformat(),
        singleEvents=True,
        orderBy="startTime",
    ).execute()

    events = events_result.get("items", [])
    output = []

    for event in events:
        start = event["start"].get("dateTime", event["start"].get("date"))
        summary = event.get("summary", "Untitled Event")
        location = event.get("location", "")
        output.append({
            "time": start,
            "title": summary,
            "location": location,
        })

    with open("agenda/calendar.json", "w") as f:
        json.dump(output, f, indent=2)

    print(f"Calendar fetched: {len(output)} events today.")


if __name__ == "__main__":
    main()
