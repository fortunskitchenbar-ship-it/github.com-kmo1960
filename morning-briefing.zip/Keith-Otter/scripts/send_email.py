"""
send_email.py
Sends the daily briefing email from fortunskitchenbar@gmail.com
to kmo1960@me.com with the full text body and MP3 attachment.
"""

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime


def main():
    gmail_user = os.environ.get("GMAIL_USER")
    gmail_password = os.environ.get("GMAIL_APP_PASSWORD")
    email_to = os.environ.get("EMAIL_TO", "kmo1960@me.com")

    if not gmail_user or not gmail_password:
        print("Missing Gmail credentials — skipping email.")
        return

    today = datetime.now().strftime("%A, %B %d")

    # Load briefing text
    try:
        with open("agenda/daily_agenda.txt", "r") as f:
            body_text = f.read()
    except Exception:
        body_text = "Your morning briefing could not be loaded today."

    # Build email
    msg = MIMEMultipart()
    msg["From"] = gmail_user
    msg["To"] = email_to
    msg["Subject"] = f"☀️ Morning Briefing — {today}"

    # Email body
    msg.attach(MIMEText(body_text, "plain"))

    # Attach MP3 if it exists
    mp3_path = "agenda/morning_briefing.mp3"
    if os.path.exists(mp3_path):
        try:
            with open(mp3_path, "rb") as f:
                mp3_data = f.read()
            attachment = MIMEBase("audio", "mpeg")
            attachment.set_payload(mp3_data)
            encoders.encode_base64(attachment)
            attachment.add_header(
                "Content-Disposition",
                "attachment",
                filename="morning_briefing.mp3"
            )
            msg.attach(attachment)
            print("MP3 attached.")
        except Exception as e:
            print(f"Could not attach MP3: {e}")
    else:
        print("No MP3 found — sending text only.")

    # Send via Gmail SMTP
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(gmail_user, gmail_password)
            server.sendmail(gmail_user, email_to, msg.as_string())
        print(f"Email sent to {email_to}")
    except Exception as e:
        print(f"Email failed: {e}")
        raise


if __name__ == "__main__":
    main()
