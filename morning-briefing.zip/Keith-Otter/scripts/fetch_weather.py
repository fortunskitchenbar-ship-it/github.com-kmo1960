"""
fetch_weather.py
Pulls current weather and today's forecast for La Quinta, CA
using Open-Meteo (no API key required).
"""

import requests
import json

LAT = 33.6636
LON = -116.3103

URL = (
    f"https://api.open-meteo.com/v1/forecast"
    f"?latitude={LAT}&longitude={LON}"
    f"&current=temperature_2m,apparent_temperature,weathercode,windspeed_10m"
    f"&daily=temperature_2m_max,temperature_2m_min,weathercode,precipitation_probability_max"
    f"&temperature_unit=fahrenheit"
    f"&windspeed_unit=mph"
    f"&precipitation_unit=inch"
    f"&timezone=America%2FLos_Angeles"
    f"&forecast_days=1"
)

WMO_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Foggy", 48: "Icy fog", 51: "Light drizzle", 53: "Drizzle",
    55: "Heavy drizzle", 61: "Light rain", 63: "Rain", 65: "Heavy rain",
    71: "Light snow", 73: "Snow", 75: "Heavy snow", 80: "Rain showers",
    81: "Heavy showers", 82: "Violent showers", 95: "Thunderstorm",
    96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail",
}

def get_condition(code):
    return WMO_CODES.get(code, "Unknown")

def main():
    resp = requests.get(URL, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    current = data["current"]
    daily = data["daily"]

    weather = {
        "current_temp": round(current["temperature_2m"]),
        "feels_like": round(current["apparent_temperature"]),
        "condition": get_condition(current["weathercode"]),
        "wind_mph": round(current["windspeed_10m"]),
        "high": round(daily["temperature_2m_max"][0]),
        "low": round(daily["temperature_2m_min"][0]),
        "precip_chance": daily["precipitation_probability_max"][0],
    }

    with open("agenda/weather.json", "w") as f:
        json.dump(weather, f, indent=2)

    print(f"Weather fetched: {weather['condition']}, {weather['current_temp']}°F")

if __name__ == "__main__":
    main()
