"""
fetch_ai_briefing.py
Uses Claude (Anthropic API) to generate a motivational, personalized
morning briefing based on weather, calendar, and headlines.
"""

import os
import json
import anthropic
from datetime import datetime

def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def main():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("No ANTHROPIC_API_KEY — skipping AI briefing.")
        with open("agenda/ai_briefing.txt", "w") as f:
            f.write("")
        return

    weather = load_json("agenda/weather.json", {})
    calendar = load_json("agenda/calendar.json", [])
    headlines = load_json("agenda/headlines.json", [])

    today = datetime.now().strftime("%A, %B %d, %Y")

    # Format calendar
    if calendar:
        cal_text = "\n".join(
            f"- {e['time']}: {e['title']}" + (f" @ {e['location']}" if e.get('location') else "")
            for e in calendar
        )
    else:
        cal_text = "No scheduled events today."

    # Format headlines
    headlines_text = "\n".join(f"- {h}" for h in headlines) if headlines else "No headlines available."

    # Format weather
    if weather:
        wx_text = (
            f"{weather.get('condition', 'Unknown')}, currently {weather.get('current_temp', '?')}°F "
            f"(feels like {weather.get('feels_like', '?')}°F). "
            f"High {weather.get('high', '?')}°F / Low {weather.get('low', '?')}°F. "
            f"Wind {weather.get('wind_mph', '?')} mph. "
            f"Rain chance: {weather.get('precip_chance', 0)}%."
        )
    else:
        wx_text = "Weather unavailable."

    prompt = f"""You are Keith's sharp, upbeat morning briefing assistant. Today is {today}.

Keith is a chef and restaurateur in La Quinta, CA going through a major life transition — he just sold his restaurant, Fortun's Kitchen + Bar, and is figuring out what's next. He needs energy, clarity, and a bit of fire to start the day.

Here's his morning data:

WEATHER (La Quinta, CA):
{wx_text}

TODAY'S CALENDAR:
{cal_text}

TOP NEWS HEADLINES:
{headlines_text}

Write a spoken morning briefing for Keith. It should:
1. Open with a punchy, motivating greeting — acknowledge the day and his situation with energy, not pity
2. Deliver the weather naturally (1-2 sentences)
3. Walk through today's calendar events clearly
4. Hit the top 3-4 most relevant headlines with brief context
5. Close with a sharp, genuine motivational send-off — something that actually lands, not generic fluff

Keep it conversational and spoken — this will be read aloud as audio. Under 400 words. No bullet points, no headers. Pure spoken word."""

    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=600,
        messages=[{"role": "user", "content": prompt}]
    )

    briefing = message.content[0].text.strip()

    with open("agenda/ai_briefing.txt", "w") as f:
        f.write(briefing)

    print("AI briefing generated.")

if __name__ == "__main__":
    main()
