"""
build_agenda.py
Combines weather, calendar, headlines, and AI briefing
into a single clean text file for email and TTS.
"""

import json
from datetime import datetime

def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def load_text(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except Exception:
        return ""

def main():
    today = datetime.now().strftime("%A, %B %d, %Y")
    weather = load_json("agenda/weather.json", {})
    calendar = load_json("agenda/calendar.json", [])
    headlines = load_json("agenda/headlines.json", [])
    ai_briefing = load_text("agenda/ai_briefing.txt")

    lines = []
    lines.append(f"GOOD MORNING, KEITH")
    lines.append(f"{today}")
    lines.append("=" * 50)
    lines.append("")

    # AI Briefing (spoken version)
    if ai_briefing:
        lines.append("YOUR MORNING BRIEFING")
        lines.append("-" * 30)
        lines.append(ai_briefing)
        lines.append("")

    # Weather
    if weather:
        lines.append("WEATHER — LA QUINTA, CA")
        lines.append("-" * 30)
        lines.append(
            f"  Now:   {weather.get('condition')} | {weather.get('current_temp')}°F "
            f"(feels like {weather.get('feels_like')}°F)"
        )
        lines.append(
            f"  Today: High {weather.get('high')}°F / Low {weather.get('low')}°F"
        )
        lines.append(f"  Wind:  {weather.get('wind_mph')} mph")
        lines.append(f"  Rain:  {weather.get('precip_chance')}% chance")
        lines.append("")

    # Calendar
    lines.append("TODAY'S SCHEDULE")
    lines.append("-" * 30)
    if calendar:
        for event in calendar:
            time_str = event.get("time", "")
            # Format time if it's a datetime string
            try:
                from datetime import datetime as dt
                t = dt.fromisoformat(time_str)
                time_str = t.strftime("%-I:%M %p")
            except Exception:
                pass
            loc = f" @ {event['location']}" if event.get("location") else ""
            lines.append(f"  {time_str}: {event['title']}{loc}")
    else:
        lines.append("  No events scheduled today.")
    lines.append("")

    # Headlines
    lines.append("FOX NEWS — TOP HEADLINES")
    lines.append("-" * 30)
    if headlines:
        for i, h in enumerate(headlines[:10], 1):
            lines.append(f"  {i}. {h}")
    else:
        lines.append("  No headlines available.")
    lines.append("")
    lines.append("=" * 50)
    lines.append("Have a great day.")

    full_text = "\n".join(lines)

    with open("agenda/daily_agenda.txt", "w") as f:
        f.write(full_text)

    # Also save just the spoken version for TTS
    spoken = ai_briefing if ai_briefing else full_text
    with open("agenda/spoken_briefing.txt", "w") as f:
        f.write(spoken)

    print("Agenda built successfully.")

if __name__ == "__main__":
    main()
