"""
fetch_rss.py
Pulls top 10 Fox News headlines from their RSS feed.
No API key required.
"""

import json
import xml.etree.ElementTree as ET
import requests

RSS_URL = "https://moxie.foxnews.com/google-publisher/latest.xml"
MAX_HEADLINES = 10


def main():
    try:
        resp = requests.get(RSS_URL, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        root = ET.fromstring(resp.content)
    except Exception as e:
        print(f"RSS fetch failed: {e}")
        with open("agenda/headlines.json", "w") as f:
            json.dump([], f)
        return

    headlines = []
    for item in root.iter("item"):
        title = item.findtext("title", "").strip()
        if title:
            headlines.append(title)
        if len(headlines) >= MAX_HEADLINES:
            break

    with open("agenda/headlines.json", "w") as f:
        json.dump(headlines, f, indent=2)

    print(f"Headlines fetched: {len(headlines)} items.")


if __name__ == "__main__":
    main()
