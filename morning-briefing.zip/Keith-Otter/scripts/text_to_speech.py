"""
text_to_speech.py
Converts the spoken briefing to an MP3 using edge-tts (Microsoft neural voices).
Uses en-US-AriaNeural — natural, clear female voice. No API key needed.
"""

import asyncio
import edge_tts

VOICE = "en-US-AriaNeural"
INPUT_FILE = "agenda/spoken_briefing.txt"
OUTPUT_FILE = "agenda/morning_briefing.mp3"


async def generate_audio():
    with open(INPUT_FILE, "r") as f:
        text = f.read().strip()

    if not text:
        print("No text to convert — skipping TTS.")
        return

    communicate = edge_tts.Communicate(text, VOICE)
    await communicate.save(OUTPUT_FILE)
    print(f"Audio saved: {OUTPUT_FILE}")


def main():
    asyncio.run(generate_audio())


if __name__ == "__main__":
    main()
